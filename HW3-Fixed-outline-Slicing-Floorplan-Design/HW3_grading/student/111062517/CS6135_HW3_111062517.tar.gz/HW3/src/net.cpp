#include "header.h"

int Net::HPWL() {
    return 0;
}
