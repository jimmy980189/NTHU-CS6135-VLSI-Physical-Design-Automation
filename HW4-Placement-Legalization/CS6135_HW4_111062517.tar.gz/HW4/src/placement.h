#include "header.h"

class Placement {
    private:
        int maxDisplacement;
        int numNodes;
        int numTerminals;
        int numRows;
        map<string, Node*> nodes;
        map<string, Node*> terminals;
        vector<Row*> rows;

        pair<double, double> base;
        int rowHeight;

    public:
        Placement() {}
        ~Placement() {
            for (auto i : nodes) delete i.second;
            for (auto i : rows) delete i;
        }

        void ReadInputFile(const char* filename);
            void ReadInputNodeFile(string filename);
            void ReadInputPlFile(string filename);
            void ReadInputSclFile(string filename);
        void GenOutputFile(const char* filename);

        double Cost();
        void Abacus();
        bool PlaceRow(int idx, Node* node);
};

